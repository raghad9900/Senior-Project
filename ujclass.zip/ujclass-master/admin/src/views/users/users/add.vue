<template>
  <div>
    <Breadcrumb
      :home="{ icon: 'pi pi-home', to: '/admin' }"
      :model="BreadcrumbItems"
    />

    <Toolbar class="p-mb-4 mt-2">
      <template #left>
        <Button
          icon="pi pi-times"
          class="p-button-danger"
          @click="$router.push('/admin/users/users')"
        />
      </template>
      <template #right>
        Add New
      </template>
    </Toolbar>
    <div class="form-card row">
      <div class="col-md-6">
        <div class="mb-3">
          <label for="firstName" class="form-label">
            First Name
          </label>
          <input
            type="text"
            class="form-control"
            id="firstName"
            v-model="body.firstName"
          />
        </div>
      </div>
      <div class="col-md-6">
        <div class="mb-3">
          <label for="lastName" class="form-label">
            Last Name
          </label>
          <input
            type="text"
            class="form-control"
            id="lastName"
            v-model="body.lastName"
          />
        </div>
      </div>

      <div class="col-md-6">
        <div class="mb-3">
          <label for="type" class="form-label">
            User Type
          </label>
          <Dropdown
          style="width: 100%;"
            v-model="body.type"
            :options="[
              {
                id: 1,
                name: 'instructor',
              },
              {
                id: 2,
                name: 'techninan',
              },
            ]"
            optionLabel="name"
            optionValue="id"
          />
          <!-- <input
            type="text"
            class="form-control"
            id="type"
            v-model="body.type"
          /> -->
        </div>
      </div>
      <div class="col-md-6">
        <div class="mb-3">
          <label for="email" class="form-label">
            email
          </label>
          <input
            type="email"
            class="form-control"
            id="email"
            v-model="body.email"
          />
        </div>
      </div>

     
      <div class="col-md-6">
        <div class="mb-3">
          <label for="password" class="form-label">
            password
          </label>
          <input
            type="password"
            class="form-control"
            id="password"
            v-model="body.password"
          />
        </div>
      </div>

      <div class="col-md-6">
        <div class="mb-3">
          <label for="confermedPassword" class="form-label">
            Confermed Password
          </label>
          <input
            type="password"
            class="form-control"
            id="password"
            v-model="body.confermedPassword"
          />
        </div>
      </div>

      <div class="col-md-12">
        <div class="mb-3 text-center">
          <Button
            label="Edit"
            icon="pi pi-pencil"
            class="p-ml-2 p-button-info"
            @click="update()"
            v-if="id"
          />
          <Button
            v-else
            label="Add"
            icon="pi pi-plus"
            class="p-ml-2 p-button-success"
            @click="save()"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      BreadcrumbItems: [
        {
          label: 'Admis',
          to: '/admin/users/users',
        },
        { label: 'Add' },
      ],
      body: {
        firstName: null,
        lastName: null,
        email: null,
        password: null,
        type: 1,

        confermedPassword: null,
      },
      id: null,
    };
  },
  methods: {
    save() {
      if (
        this.body.firstName &&
        this.body.lastName &&
        this.body.email &&
        this.body.password &&
        this.body.confermedPassword &&
        this.body.password == this.body.confermedPassword
      ) {
        this.$http.post(`users`, this.body).then(
          () => {
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Added Done Success',
              life: 3000,
            });
            this.$router.push('/admin/users/users');
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      } else {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Please fill fields',
          life: 3000,
        });
      }
    },
    update() {
      if (this.body.firstName &&
        this.body.lastName &&
        this.body.email) {
        this.$http.put(`users/${this.id}`, this.body).then(
          () => {
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Edit Done Success',
              life: 3000,
            });
            this.$router.push('/admin/users/users');
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      } else {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Please fill fields',
          life: 3000,
        });
      }
    },
  },
  created() {
    if (this.$route.params.id) {
      this.id = this.$route.params.id;
      this.$http.get(`users/${this.id}`).then(
        (res) => {
          this.body = res.data;
          this.body.password = null;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    }
  },
};
</script>
