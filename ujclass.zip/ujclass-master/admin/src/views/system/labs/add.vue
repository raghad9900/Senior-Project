<template>
  <div>
    <Breadcrumb
      :home="{ icon: 'pi pi-home', to: '/admin' }"
      :model="BreadcrumbItems"
    />

    <Toolbar class="p-mb-4 mt-2">
      <template #left>
        <Button
          icon="pi pi-times"
          class="p-button-danger"
          @click="$router.go(-1)"
        />
      </template>
      <template #right>
        Add New
      </template>
    </Toolbar>
    <div class="form-card row">
      <div class="col-md-12">
        <div class="mb-3">
          <label for="image" class="form-label">
            Image
          </label>
          <span
            v-if="id && body.image"
            style="color:red"
            @click="body.image = null"
            >X</span
          >
          <img
            :src="$baseUploadURL + body.image"
            v-if="id && body.image"
            class="profile-pic height-150 width-150 align-items-center"
            style="width: 100px;height: 100px;"
          />
          <div class="">
            <i class="ri-pencil-line upload-button"></i>
            <b-form-file
              class="h-100 "
              accept="image/*"
              @change="previewImage"
            ></b-form-file>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="mb-3">
          <label for="name" class="form-label">
            Name
          </label>
          <input
            type="text"
            class="form-control"
            id="name"
            v-model="body.name"
          />
        </div>
      </div>

      <div class="col-md-6">
        <div class="mb-3">
          <label for="type" class="form-label">
             Type
          </label>
          <Dropdown
            style="width: 100%;"
            v-model="body.type"
            :options="[
              {
                id: 1,
                name: 'Class',
              },
              {
                id: 2,
                name: 'Lab',
              },
            ]"
            optionLabel="name"
            optionValue="id"
          />
          <!-- <input
            type="text"
            class="form-control"
            id="type"
            v-model="body.type"
          /> -->
        </div>
      </div>

      <div class="col-md-12">
        <div class="mb-3">
          <label for="body" class="form-label">
            Body
          </label>
          <textarea class="form-control" id="body" v-model="body.body" />
        </div>
      </div>
      <div class="col-md-12">
        <div class="mb-3 text-center">
          <Button
            label="Edit"
            icon="pi pi-pencil"
            class="p-ml-2 p-button-info"
            @click="update()"
            v-if="id"
          />
          <Button
            v-else
            label="Add"
            icon="pi pi-plus"
            class="p-ml-2 p-button-success"
            @click="save()"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      BreadcrumbItems: [
        {
          label: 'Admis',
          to: '/admin/system/labs',
        },
        { label: 'Add' },
      ],
      body: {
        name: null,
        image: null,
        type: 1,
        body: null,
      },
      id: null,
    };
  },
  methods: {
    previewImage(ev) {
      this.$file2base64(ev, (image) => {
        this.body.image = image;
      });
    },
    save() {
      if (this.body.name && this.body.type && this.body.body) {
        this.$http.post(`labs`, this.body).then(
          () => {
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Added Done Success',
              life: 3000,
            });
            this.$router.go(-1);
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      } else {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Please fill fields',
          life: 3000,
        });
      }
    },
    update() {
      if (this.body.name && this.body.body) {
        this.$http.put(`labs/${this.id}`, this.body).then(
          () => {
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Edit Done Success',
              life: 3000,
            });
            this.$router.go(-1);
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      } else {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Please fill fields',
          life: 3000,
        });
      }
    },
  },
  created() {
    if (this.$route.params.id) {
      this.id = this.$route.params.id;
      this.$http.get(`labs/${this.id}`).then(
        (res) => {
          this.body = res.data;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    }
  },
};
</script>
