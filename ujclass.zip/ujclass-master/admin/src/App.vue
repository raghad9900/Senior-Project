<template>
  <div id="app">
    <Toast position="top-left" />
    <ConfirmDialog></ConfirmDialog>
    <router-view />
  </div>
</template>
