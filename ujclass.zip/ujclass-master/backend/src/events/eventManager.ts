const events = require('events')

export class EventManager extends events.EventEmitter {
    constructor() { super() }
}


