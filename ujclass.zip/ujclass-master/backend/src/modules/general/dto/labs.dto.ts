import {
  IsString,
  IsMongoId,
  IsOptional,
  IsObject,
  IsNotEmpty,
  ValidateIf,
  IsNumber,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { LangDto } from 'src/common/base/baseDto.dto';

export class Labs {
  @IsString()
  @ApiProperty()
  name: String;



  

  @IsNumber()
  @ApiProperty()
  type: String;

  @IsString()
  @ApiProperty()
  body: String;


 
  
}
