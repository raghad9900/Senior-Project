import * as mongoose from 'mongoose';
import { LangReq } from 'src/common/base/baseSchema.schema';
import { loadedAtPlugin, ObjectId } from 'src/common/helpers/mongoose';

const IssuesSchema = new mongoose.Schema(
  {
    id: {
      type: Number,
    },
    body: { type: String, required: true },
    status: { type: String, required: true },
    preority: { type: String, default: null, required: false },
    files: { type: Array },
    labId: {
      type: ObjectId,
      ref: 'labs',
      autopopulate: true,
    },
    userId: {
      type: ObjectId,
      ref: 'users',
      autopopulate: true,
    },
    issueTypeId: {
      type: ObjectId,
      ref: 'issues_types',
      autopopulate: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(IssuesSchema);

export { IssuesSchema };
