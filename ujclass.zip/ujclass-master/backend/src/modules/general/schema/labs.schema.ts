import * as mongoose from 'mongoose';
import { loadedAtPlugin, ObjectId } from 'src/common/helpers/mongoose';

const LabsSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      default: null,

      required: false,
    },
    type: {
      type: Number,
      required: true,
      default: 1,
    },
    body: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(LabsSchema);

export { LabsSchema };
