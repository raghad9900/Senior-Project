import * as mongoose from 'mongoose';
import { LangReq } from 'src/common/base/baseSchema.schema';
import { loadedAtPlugin, ObjectId } from 'src/common/helpers/mongoose';

const BookingSchema = new mongoose.Schema(
  {
    startTime: { type: String, required: true },
    endTime: { type: String, required: true },
    status: { type: String, required: true },
    labId: {
      type: ObjectId,
      ref: 'labs',
      autopopulate: true,
    },
    userId: {
      type: ObjectId,
      ref: 'users',
      autopopulate: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(BookingSchema);

export { BookingSchema };
