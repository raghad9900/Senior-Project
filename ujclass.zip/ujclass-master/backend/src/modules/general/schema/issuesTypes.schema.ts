import * as mongoose from 'mongoose';
import { loadedAtPlugin, ObjectId } from 'src/common/helpers/mongoose';

const IssuesTypesSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(IssuesTypesSchema);

export { IssuesTypesSchema };
