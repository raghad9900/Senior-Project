import * as mongoose from 'mongoose';
import { loadedAtPlugin, ObjectId } from 'src/common/helpers/mongoose';

const CommentsSchema = new mongoose.Schema(
  {
    body: { type: String, required: true },
    status: { type: String, required: true },

    userId: {
      type: ObjectId,
      ref: 'users',
      autopopulate: true,
    },
    issueId: {
      required: true,
      type: ObjectId,
      ref: 'issues',
      autopopulate: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(CommentsSchema);

export { CommentsSchema };
