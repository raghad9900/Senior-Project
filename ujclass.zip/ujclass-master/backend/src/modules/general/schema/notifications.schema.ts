import * as mongoose from 'mongoose';
import { loadedAtPlugin, ObjectId } from 'src/common/helpers/mongoose';

const NotificationsSchema = new mongoose.Schema(
  {
    body: { type: String, required: true },
    status: { type: String, default: 'new', required: false },

    userId: {
      type: ObjectId,
      ref: 'users',
      autopopulate: true,
    },
    issueId: {
      required: true,
      type: ObjectId,
      ref: 'issues',
      autopopulate: true,
    },
    commentsId: {
      type: ObjectId,
      ref: 'comments',
      autopopulate: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(NotificationsSchema);

export { NotificationsSchema };
