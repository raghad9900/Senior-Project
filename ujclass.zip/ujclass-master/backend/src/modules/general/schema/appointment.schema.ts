import * as mongoose from 'mongoose';
import { loadedAtPlugin, ObjectId } from 'src/common/helpers/mongoose';

const AppointmentSchema = new mongoose.Schema(
  {
    cancelid: { 
      type: Boolean, 
      default: false, 
      required: false 
    },
    start: {
      type: String,
      required: true,
    },
    end: {
      type: String,
      required: true,
    },
   
    
    labId: {
      required: true,
      type: ObjectId,
      ref: 'labs',
      autopopulate: true,
    },
    userId: {
      type: ObjectId,
      ref: 'users',
      autopopulate: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(AppointmentSchema);

export { AppointmentSchema };
