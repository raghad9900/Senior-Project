import { Model } from 'mongoose';
import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { BaseService } from 'src/common/base/baseService.service';
import { query } from 'express';

@Injectable()
export class IssuesService extends BaseService {
  constructor(@InjectModel('issues') public readonly model: Model<any>) {
    super(model);
  }

  async findOneId() {
    try {
      return await this.model.findOne().sort({ id: '-1' });
    } catch (e) {
      throw new HttpException(e.message, HttpStatus.METHOD_NOT_ALLOWED);
    }
  }
}
