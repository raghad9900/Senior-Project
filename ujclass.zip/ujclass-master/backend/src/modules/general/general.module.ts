import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';

import { LabsController } from './controllers/labs.controller';
import { BookingController } from './controllers/booking.controller';

import { LabsSchema } from './schema/labs.schema';
import { BookingSchema } from './schema/booking.schema';

import { LabsService } from './services/labs.service';
import { BookingService } from './services/booking.service';
import { IssuesController } from './controllers/issues.controller';
import { IssuesTypesController } from './controllers/issuesTypes.controller';
import { IssuesService } from './services/issues.service';
import { IssuesTypesService } from './services/issuesTypes.service';
import { IssuesSchema } from './schema/issues.schema';
import { IssuesTypesSchema } from './schema/issuesTypes.schema';
import { CommentsController } from './controllers/comments.controller';
import { CommentsService } from './services/comments.service';
import { CommentsSchema } from './schema/comments.schema';
import { NotificationsSchema } from './schema/notifications.schema';
import { NotificationsController } from './controllers/notifications.controller';
import { NotificationsService } from './services/notifications.service';
import { UserSchema } from '../users/schema/users.schema';
import { AppointmentSchema } from './schema/appointment.schema';
import { AppointmentController } from './controllers/appointment.controller';
import { AppointmentService } from './services/appointment.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'labs',
        schema: LabsSchema,
        collection: 'labs',
      },
      {
        name: 'booking',
        schema: BookingSchema,
        collection: 'booking',
      },
      {
        name: 'issues',
        schema: IssuesSchema,
        collection: 'issues',
      },
      {
        name: 'issues_types',
        schema: IssuesTypesSchema,
        collection: 'issues_types',
      },

      {
        name: 'comments',
        schema: CommentsSchema,
        collection: 'comments',
      },
      {
        name: 'notifications',
        schema: NotificationsSchema,
        collection: 'notifications',
      },
      { name: 'users', schema: UserSchema },
      {
        name: 'appointments',
        schema: AppointmentSchema,
        collection: 'appointments',
      },
    ]),
  ],
  controllers: [
    LabsController,
    BookingController,
    IssuesController,
    IssuesTypesController,
    CommentsController,
    NotificationsController,
    AppointmentController,
  ],
  providers: [
    LabsService,
    BookingService,
    IssuesService,
    IssuesTypesService,
    CommentsService,
    NotificationsService,
    AppointmentService,
  ],
})
export class GeneralModule {}
