import * as mongoose from 'mongoose';

import * as bcrypt from 'bcryptjs';

import { loadedAtPlugin, ObjectId, Enums } from 'src/common/helpers/mongoose';

const UserSchema = new mongoose.Schema(
  {
    image: {
      type: String,
      default: null,
      required: false,
    },
    firstName: {
      type: String,
      trim: true,
      required: true,
    },

    lastName: {
      type: String,
      trim: true,
      required: true,
    },
    email: {
      type: String,
      trim: true,
      required: true,
    },

    type: {
      type: Number,
      default: 1,
      required: true,
    },

    password: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

UserSchema.index(
  {
    email: 1,
  },
  {
    unique: true,
  },
);

loadedAtPlugin(UserSchema);

UserSchema.pre<any>('save', function(next) {
  bcrypt.genSalt(10, (err, salt) => {
    if (err) {
      return next(err);
    }
    bcrypt.hash(this.password, salt, (err2, hash: any) => {
      if (err2) {
        return next(err2);
      }
      this.password = hash;
      next();
    });
  });
});

// UserSchema.pre<any>('insertMany', function(next) {

//   bcrypt.genSalt(10, (err, salt) => {
//     if (err) {
//       return next(err);
//     }
//     bcrypt.hash(this.password, salt, (err2, hash: any) => {
//       if (err2) {
//         return next(err2);
//       }
//       this.password = hash;
//       next();
//     });
//   });
// });

UserSchema.pre<any>('updateOne', function(next) {
  if (this._update.password) {
    bcrypt.genSalt(10, (err, salt) => {
      if (err) {
        return next(err);
      }
      bcrypt.hash(this._update.password, salt, (err2, hash: any) => {
        if (err2) {
          return next(err2);
        }
        this._update.password = hash;
        next();
      });
    });
  } else {
    next();
  }
});
UserSchema.methods.isPasswordMatch = bcrypt.compareSync;

export { UserSchema };
