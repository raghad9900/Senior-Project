import * as mongoose from 'mongoose';

import * as bcrypt from 'bcryptjs';

import { loadedAtPlugin, ObjectId, Enums } from 'src/common/helpers/mongoose';

const AdminsSchema = new mongoose.Schema(
  {
    userName: {
      type: String,
      trim: true,
      required: true,
      unique: true,
    },

    email: {
      type: String,
      trim: true,
      required: true,
      unique: true,
    },
    phone: {
      type: String,
      trim: true,
      required: true,
      unique: true,
    },

    password: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

loadedAtPlugin(AdminsSchema);

AdminsSchema.pre<any>('save', function(next) {
  bcrypt.genSalt(10, (err, salt) => {
    if (err) {
      return next(err);
    }
    bcrypt.hash(this.password, salt, (err2, hash: any) => {
      if (err2) {
        return next(err2);
      }
      this.password = hash;
      next();
    });
  });
});

// AdminsSchema.pre<any>('insertMany', function(next) {

//   bcrypt.genSalt(10, (err, salt) => {
//     if (err) {
//       return next(err);
//     }
//     bcrypt.hash(this.password, salt, (err2, hash: any) => {
//       if (err2) {
//         return next(err2);
//       }
//       this.password = hash;
//       next();
//     });
//   });
// });

AdminsSchema.pre<any>('updateOne', function(next) {
  if (this._update.password) {
    bcrypt.genSalt(10, (err, salt) => {
      if (err) {
        return next(err);
      }
      bcrypt.hash(this._update.password, salt, (err2, hash: any) => {
        if (err2) {
          return next(err2);
        }
        this._update.password = hash;
        next();
      });
    });
  } else {
    next();
  }
});
AdminsSchema.methods.isPasswordMatch = bcrypt.compareSync;

export { AdminsSchema };
