import { filter } from 'rxjs/operators';
import { Model } from 'mongoose';
import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { BaseService } from 'src/common/base/baseService.service';



@Injectable()
export class AdminsService extends BaseService {
  constructor(
    @InjectModel('admins') public readonly model: Model<any>
  
  ) {
    super(model);
  }

  

  

}
