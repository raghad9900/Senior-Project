import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtService } from '@nestjs/jwt';
import { AdminsService } from './admins.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly adminsService: AdminsService,
    private readonly jwtService: JwtService,
  ) {}

  async authenticationLogin(body: any) {
    const user = await this.usersService.findOne({
      email: body.email,
    });
    if (!user) {
      throw new HttpException(
        'Error, Account not found',
        HttpStatus.METHOD_NOT_ALLOWED,
      );
    } else {
      const isMatch = await user.isPasswordMatch(body.password, user.password);
      // Invalid password
      if (!isMatch) {
        throw new HttpException(
          'Error, Invalid Password',
          HttpStatus.METHOD_NOT_ALLOWED,
        );
      } else {
        return await {
          token: this.jwtService.sign({
            _id: user._id,
            name: user.name,
          }),
          _id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          type: user.type,
          image: user.image,
        };
      }
    }
  }

  async adminLogin(body: any) {
    if (body.userName === 'admin' && body.password === `123456`) {
      return await {
        _id: '000000000000000000000000',
        userName: body.userName,

        token: this.jwtService.sign({
          id: '000000000000000000000000',
        }),
      };
    } else {
      const user = await this.adminsService.findOne({
        userName: body.userName,
      });
      if (!user) {
        throw new HttpException(
          'Error, Account not found',
          HttpStatus.METHOD_NOT_ALLOWED,
        );
      } else {
        const isMatch = await user.isPasswordMatch(
          body.password,
          user.password,
        );
        // Invalid password
        if (!isMatch) {
          throw new HttpException(
            'Error, Invalid Password',
            HttpStatus.METHOD_NOT_ALLOWED,
          );
        } else {
          return await {
            token: this.jwtService.sign({
              _id: user._id,
              name: user.name,
            }),
            ...user,
          };
        }
      }
    }
  }

  async create(body) {
    try {
      return await this.usersService.create(body);
    } catch (e) {
      throw new HttpException(e.message, HttpStatus.METHOD_NOT_ALLOWED);
    }
  }
}
