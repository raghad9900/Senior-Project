import {
  Length,
  IsString,
  IsOptional,
  ValidateIf,
  IsNumber,
  IsEmail,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class Admins {
  @IsString()
  @Length(3, 250)
  @ApiProperty()
  userName: string;

  @IsEmail()
  @ApiProperty()
  email: string;

  @IsString()
  @Length(3, 250)
  @ApiProperty()
  phone: string;

  @IsString()
  @IsOptional()
  @ValidateIf((e) => e === null)
  @ApiProperty({ required: false })
  password?: string;

}
