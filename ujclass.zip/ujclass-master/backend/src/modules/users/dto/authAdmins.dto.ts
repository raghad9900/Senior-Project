import { IsString, IsMongoId, IsOptional, IsEmail } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class AuthAdmin {

    @IsString()
    @ApiProperty()
    userName: string;

    @IsString()
    @ApiProperty()
    password: string;

 
    

}
