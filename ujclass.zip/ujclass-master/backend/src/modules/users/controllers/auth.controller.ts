import { Controller, Post, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { AuthService } from '../services/auth.service';
import { ApiCreatedResponse, ApiTags } from '@nestjs/swagger';
import { Auth } from '../dto/auth.dto';
import { User } from '../dto/users.dto';
import { AuthAdmin } from '../dto/authAdmins.dto';

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  
  @Post('login')
  @ApiCreatedResponse({
    type: Auth,
  })
  @HttpCode(HttpStatus.OK)
  async authenticationLogin(@Body() body: Auth) {
    return await this.authService.authenticationLogin(body);
  }


  @Post('adminLogin')
  @ApiCreatedResponse({
    type: AuthAdmin,
  })
  @HttpCode(HttpStatus.OK)
  async adminLogin(@Body() body: AuthAdmin) {
    return await this.authService.adminLogin(body);
  }

  @Post('signup')
  @ApiCreatedResponse({
    type: User,
  })
  @HttpCode(HttpStatus.OK)
  async signup(@Body() body: User) {
    return await this.authService.create(body);
  }


  
}
