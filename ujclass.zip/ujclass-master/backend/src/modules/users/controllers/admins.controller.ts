import {
  Controller,
  Post,
  Body,
  Query,
  Get,
  Put,
  Delete,
  Param,
  UseGuards,
  Req,
  HttpCode,
  HttpStatus,
  HttpException,
} from '@nestjs/common';
import { Admins } from '../dto/admins.dto';
import { AdminsService } from '../services/admins.service';
import { ApiCreatedResponse, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { BaseController } from 'src/common/base/baseController.controller';
import { UserInfo } from 'src/common/decorator/user.decorator';

@ApiTags('Admins')
@Controller('admins')
@UseGuards(AuthGuard('jwt'))
export class AdminsController extends BaseController {
  constructor(public readonly adminsService: AdminsService) {
    super(adminsService);
  }
  @Post()
  @ApiCreatedResponse({
    description: 'The record has been successfully created.',
    type: Admins,
  })
  async create(@Body() body: Admins) {
    await this.validatePassword(body);
    return await this.adminsService.create(body);
  }

  @Post('search')
  @HttpCode(HttpStatus.OK)
  async search(@Body() body, @Query() options, @UserInfo() user) {
    return await this.service.findAll(body, options);
  }

  @Put(':id')
  @ApiCreatedResponse({
    description: 'The record has been successfully updated.',
    type: Admins,
  })
  async update(@Param('id') id: string, @Body() body: Admins) {
    return await this.adminsService.updateById(id, body);
  }

  async validatePassword(body) {
    if (body.password == null) {
      throw new HttpException(
        'Error , password is missing',
        HttpStatus.METHOD_NOT_ALLOWED,
      );
    } else {
      return await true;
    }
  }
}
