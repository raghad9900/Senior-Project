import { Module } from '@nestjs/common';
import { UsersController } from './controllers/users.controller';
import { UsersService } from './services/users.service';
import { MongooseModule } from '@nestjs/mongoose';
import { UserSchema } from './schema/users.schema';
import { AuthService } from './services/auth.service';
import { AuthController } from './controllers/auth.controller';
import { JwtStrategy } from 'src/common/strategy/jwt.strategy';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';

import * as config from 'src/config.json';
import { AdminsController } from './controllers/admins.controller';
import { AdminsService } from './services/admins.service';
import { AdminsSchema } from './schema/admins.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'users', schema: UserSchema },
    { name: 'admins', schema: AdminsSchema }]),
    PassportModule,
    JwtModule.register({
      secret: config.SECRET_KEY,
      signOptions: { expiresIn: '70d' },
    }),
  ],
  controllers: [UsersController, AdminsController, AuthController],
  providers: [AuthService, AdminsService, UsersService, JwtStrategy],
  exports: [UsersService],
})
export class UsersModule {}
