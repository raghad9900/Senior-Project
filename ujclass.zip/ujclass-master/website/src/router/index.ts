import Vue from 'vue';
import VueRouter, { RouteConfig } from 'vue-router';
import AuthLayOut from '../layout/auth/layout.vue';
import WebsiteLayOut from '../layout/website/layout.vue';

Vue.use(VueRouter);
const ifAuthenticated = (to: any, from: any, next: any) => {
  if (localStorage.ujclassUser) {
    next();
    return;
  }
  next('/');
};

const ifAuthenticatedTypeUser = (to: any, from: any, next: any) => {
  const user = JSON.parse(localStorage.ujclassUser);

  if (user.type == 1) {
    next();
    return;
  }
  next('/console/tech');
};

const ifAuthenticatedTypeTech = (to: any, from: any, next: any) => {
  const user = JSON.parse(localStorage.ujclassUser);

  if (user.type ==2) {
    next();
    return;
  }
  next('/console');
};

const ifNotAuthenticated = (to: any, from: any, next: any) => {
  if (!localStorage.ujclassUser) {
    next();
    return;
  }
  next('/console');
};

const routes: RouteConfig[] = [
  {
    path: '/',
    component: AuthLayOut,
    beforeEnter: ifNotAuthenticated,
    children: [
      {
        path: '/',
        component: () => import('../views/home.vue'),
      },
      {
        path: '/login',
        component: () => import('../views/login.vue'),
      },
      {
        path: '/signup/:id',
        component: () => import('../views/signup.vue'),
      },
    ],
  },
  {
    path: '/console',
    component: WebsiteLayOut,
    beforeEnter: ifAuthenticated,
    children: [
      {
        path: '',
        beforeEnter: ifAuthenticatedTypeUser,

        component: () => import('../views/console/home.vue'),
      },
      {
        path: 'tech',
        beforeEnter: ifAuthenticatedTypeTech,
        component: () => import('../views/console/tech/home.vue'),
      },
      {
        path: 'calendar',
        component: () => import('../views/console/calendar.vue'),
      },
      {
        path: 'myNotifications',
        component: () => import('../views/console/myNotifications.vue'),
      },
      {
        path: 'addIssues',
        component: () => import('../views/console/addIssues.vue'),
      },
      {
        path: 'issues/:id',
        component: () => import('../views/console/issues.vue'),
      },
      

      {
        path: 'showIssues/:id',
        component: () => import('../views/console/tech/showIssues.vue'),
      },
      // showAppointment
      {
        path: 'showAppointment/:id',
        component: () => import('../views/console/showAppointment.vue'),
      },
      {
        path: 'list',
        component: () => import('../views/console/tech/list.vue'),
      },
      {
        path: 'profile',
        component: () => import('../views/console/profile.vue'),
      },
    ],
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
