<template>
  <div class="container pt-5 ">
    <div class="row">
      <div class="col-5">
        <Card class="add-card">
          <template #content>
            <form @submit.prevent="add()">
              <div class="text-center" style="padding: 10px">
                <i
                  class="pi pi-times-circle"
                  v-if="body.image"
                  style="color: #c0392b; position: absolute; padding: 6px"
                  @click="body.image = null"
                ></i>

                <img
                  :src="body.image"
                  style="height: 85px; width: 85px"
                  v-if="body.image != null"
                  class="rounded"
                  alt="Utajer"
                />
                <img
                  v-else
                  src="../../assets/11.png"
                  class="rounded p-1"
                  alt="Utajer"
                  @click="$refs.file1.click()"
                />

                <input
                  type="file"
                  ref="file1"
                  style="display: none"
                  accept="image/*"
                  @change="addImage1"
                />
              </div>
              <div class="form-group text-left row mr-1 ml-1">
                <InputText
                  class=" col-6"
                  v-model="body.firstName"
                  style="width: 98%;"
                  placeholder="First Name"
                />
                <InputText
                  class=" col-6"
                  v-model="body.lastName"
                  style="width: 100%;"
                  placeholder="Last Name"
                />
              </div>
              <div class="form-group text-left">
                <InputText
                  type="email"
                  id="email"
                  style="width: 100%;"
                  placeholder="Email address *"
                  v-model="body.email"
                />
              </div>

              <div class="form-group text-left">
                <InputText
                  type="password"
                  style="width: 100%;"
                  id="password"
                  v-model="body.password"
                  placeholder="password *"
                />
              </div>

              <div class="mb-3">
                <button class="btn btn-info btn-block">Update</button>
              </div>
            </form>
          </template>
        </Card>
      </div>
    </div>
    <div class="col-3"></div>
    <div class="col-4"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      body: {
        firstName: null,
        lastName: null,
        type: 1,
        email: null,
        password: null,
        image: null,
      },
    };
  },
  methods: {
    addImage1(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) return;
      this.$file2base64(e, (image) => {
        this.body.image = image;
      });
    },
    getData() {
      const user = JSON.parse(localStorage.ujclassUser);
      const id = user._id;
      this.$http.get(`users/${id}`).then(
        (response) => {
          this.body = response.data;
          this.body.image = this.$baseUploadURL + response.data.image;
          delete this.body.password;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    },

    add() {
      if (this.body.image.startsWith('http')) {
        delete this.body.image;
      }
      if (this.body.firstName && this.body.lastName && this.body.email) {
        if (this.body.password == null) {
          delete this.body.password;
        }
        this.$http.put(`users/${this.body._id}`, this.body).then(
          (response) => {
            const user = JSON.parse(localStorage.ujclassUser);
            localStorage.ujclassUser = JSON.stringify({
              token: user.token,
              ...response.data,
            });

            location.reload();
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      }
    },
    async previewImage(ev) {
      if (ev.target.files.length > 0) {
        const list = [];
        for (const item of ev.target.files) {
          const itm = await this.$toBase64(item);
          await this.body.files.push(itm);
        }
        // this.body.files = await list;
      }
      //  else {
      //   this.body.files = [];
      // }
      return await true;
    },
  },
  created() {
    this.getData();
  },
};
</script>

<style></style>
