<template>
  <div class="container pt-5 home">
    <h1>Hello {{ name }},</h1>
    <p>
      Here are avilable halls for you

      <span
        style="font-size: 17px;float: right;"
        @click="$router.push('/console/calendar')"
      >
        see ({{ totalRecords - 3 }}) More
      </span>
    </p>
    <div class="row">
      <div class="col-4" v-for="item in labsList" :key="item.id">
        <Card class="home-card">
          <template #content>
            <div class="row-box">
              <div class="col-box">
                <p>{{ item.type == 1 ? 'Class' : 'Lab' }}</p>
                <h3>{{ item.name }}</h3>
                <p class="text">
                  {{ item.body }}
                </p>
              </div>
              <div class="col-box">
                <img :src="$baseUploadURL + item.image" alt="" />
              </div>
            </div>
          </template>
        </Card>
      </div>
    </div>
    <div class="home-part">
      <p>
        Your schedualed booking
      </p>
      <div class="row">
        <div class="col-4" v-for="item of appointmentList" :key="item._id">
          <Card class="home-card">
            <template #content>
              <SpeedDial
                class="speedbtn"
                :model="items2"
                type="quarter-circle"
                showIcon="fa fa-ellipsis-v"
                buttonClassName="p-button-text"
                :radius="100"
                @click="active2(item)"
                direction="down-left"
              />

              <h3>
                {{ item.labId ? item.labId.name : '' }}
              </h3>
              <div class="row">
                <div class="col-5" style="padding-right: 0;">
                  <p class="header">
                    Starts
                  </p>
                  <p class="date">
                    {{ $durationFormatFull(item.start) }}
                  </p>
                </div>
                <div class="col-2  text-center">
                  <i class="pi pi-arrow-right"></i>
                </div>
                <div class="col-5" style="padding: 0;">
                  <p class="header">
                    Ends
                  </p>
                  <p class="date">
                    {{ $durationFormatFull(item.end) }}
                  </p>
                </div>
              </div>
              <div class="text-right pt-1">
                <Chip
                  class="Canceled"
                  label="Canceled"
                  icon="pi pi-times-circle"
                  v-if="item.cancelid"
                />
                <Chip
                  v-else
                  class="upcoming"
                  label="upcoming"
                  icon="pi pi-clock"
                />
              </div>
            </template>
          </Card>
        </div>
      </div>
    </div>
    <div class="home-part mb-5">
      <p>
        Reported Issues
      </p>
      <div class="row">
        <div class="col-4" v-for="item in issuesList" :key="item._id">
          <Card class="home-card">
            <template #content>
              <SpeedDial
                class="speedbtn"
                :model="items"
                type="quarter-circle"
                showIcon="fa fa-ellipsis-v"
                buttonClassName="p-button-text"
                :radius="80"
                direction="down-left"
                @click="active(item)"
              />

              <h3>
                {{ item.labId ? item.labId.name : '' }}
              </h3>
              <p class="header">
                Posted in
              </p>
              <p class="date">
                {{ $durationFormatFull(item.createdAt) }}
              </p>
              <p class="header">
                Issue
              </p>
              <p class="date">
                {{ item.body }}
              </p>

              <div class="text-right pt-1">
                <Chip
                  class="new"
                  label="New"
                  v-if="item.status == 'new'"
                  icon="pi pi-envelope"
                />
                <Chip
                  class="biding"
                  v-if="item.status == 'biding'"
                  label="biding"
                  icon="pi pi-clock"
                />
                <Chip
                  class="fixed"
                  v-if="item.status == 'fixed'"
                  label="fixed"
                  icon="pi pi-check-circle"
                />
              </div>
            </template>
          </Card>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      items: [
        {
          label: 'Delete',
          icon: 'pi pi-trash',
          command: () => {
            this.$http.delete(`issues/${this.itemId}`).then(
              (response) => {
                this.getData();
                this.$toast.add({
                  severity: 'error',
                  summary: 'Delete',
                  detail: 'Data Deleted',
                });
              },
              (err) => {
                this.$toast.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: err.response.data.message,
                  life: 3000,
                });
              },
            );
          },
        },
        {
          label: 'Update',
          icon: 'pi pi-pencil',
          command: () => {
            this.$router.push('/console/issues/' + this.itemId);
          },
        },

        {
          label: 'show',
          icon: 'pi pi-eye',
          command: () => {
            this.$router.push('/console/showIssues/' + this.itemId);
          },
        },
      ],
      items2: [
        {
          label: 'Delete',
          icon: 'pi pi-trash',
          command: () => {
            this.$http.delete(`appointment/${this.itemId2}`).then(
              (response) => {
                this.getData();
                this.$toast.add({
                  severity: 'error',
                  summary: 'Delete',
                  detail: 'Data Deleted',
                });
              },
              (err) => {
                this.$toast.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: err.response.data.message,
                  life: 3000,
                });
              },
            );
          },
        },
        {
          label: 'cancelid',
          icon: 'pi pi-pencil',
          command: () => {
            this.$http
              .put(`appointment/${this.itemId2}`, {
                cancelid: true,
              })
              .then(
                (response) => {
                  this.getData();
                  this.$toast.add({
                    severity: 'error',
                    summary: 'Cancelid',
                    detail: 'Cancelid Done',
                  });
                },
                (err) => {
                  this.$toast.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: err.response.data.message,
                    life: 3000,
                  });
                },
              );
          },
        },

        {
          label: 'show',
          icon: 'pi pi-eye',
          command: () => {
            this.$router.push('/console/showAppointment/' + this.itemId2);
          },
        },
      ],
      totalRecords: 0,

      issuesList: [],
      itemId: null,
      itemId2: null,
      name: null,
      labsList: [],
      appointmentList: [],
    };
  },
  methods: {
    active(item) {
      this.itemId = item._id;
    },
    active2(item) {
      this.itemId2 = item._id;
    },
    toggle(event) {
      this.$refs.menu.toggle(event);
    },
    getData() {
      const user = JSON.parse(localStorage.ujclassUser);
      this.name = user.firstName;
      this.$http
        .post(`issues/search?page=1&limit=3`, {
          userId: user._id,
        })
        .then(
          (response) => {
            this.issuesList = response.data.docs;
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );

      this.$http
        .post(`appointment/search?page=1&limit=3&sort=asc`, {
          userId: user._id,
        })
        .then(
          (response) => {
            this.appointmentList = response.data.docs;
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
    },
  },
  created() {
    this.$http.get(`labs?page=1&limit=3&sort=asc`).then(
      (response) => {
        this.labsList = response.data.docs;

        this.totalRecords = response.data.totalDocs;
      },
      (err) => {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: err.response.data.message,
          life: 3000,
        });
      },
    );
    this.getData();
  },
};
</script>

<style></style>
