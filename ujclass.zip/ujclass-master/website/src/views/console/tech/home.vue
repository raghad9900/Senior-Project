<template>
  <div class="container pt-5 home">
    <h1>Hello {{ name }},</h1>
    <p>
      This is what we have got for you today
    </p>
    <div class="row">
      <div class="col-12 text-center">
        <Card class="home-card mb-4" style="width: 40%;margin: auto;">
          <template #content>
            <div class="row-box">
              <div class="col-box">
                <h3>Total Issues</h3>
                <p>
                  <span
                    style="font-size: 63px;color: #030303;font-weight: bold;"
                  >
                    {{ total }}
                  </span>
                  Reported issues
                </p>
              </div>
              <div class="col-box">
                <img
                  style="box-shadow: none;height: 100%;"
                  src="../../../assets/eroor.jpg"
                  alt=""
                />
              </div>
            </div>
          </template>
        </Card>
      </div>
      <div class="col-4">
        <Card class="home-card mb-4">
          <template #content>
            <div class="row-box">
              <div class="col-box">
                <h3>New Issues</h3>
                <p>
                  <span
                    style="font-size: 63px;color: #030303;font-weight: bold;"
                  >
                    {{ newI }}
                  </span>
                  For Today
                </p>
              </div>
              <div class="col-box">
                <img
                  style="box-shadow: none;height: 100%;"
                  src="../../../assets/170059889653.jpg"
                  alt=""
                />
              </div>
            </div>
          </template>
        </Card>
      </div>
      <div class="col-4">
        <Card class="home-card mb-4">
          <template #content>
            <div class="row-box">
              <div class="col-box">
                <h3>Wating Issues</h3>
                <p>
                  <span
                    style="font-size: 63px;color: #030303;font-weight: bold;"
                  >
                    {{ wetting + reOpen }}
                  </span>
                  Not Sloved
                </p>
              </div>
              <div class="col-box">
                <img
                  style="box-shadow: none;height: 100%;"
                  src="../../../assets/wating.jpg"
                  alt=""
                />
              </div>
            </div>
          </template>
        </Card>
      </div>
      <div class="col-4">
        <Card class="home-card mb-4">
          <template #content>
            <div class="row-box">
              <div class="col-box">
                <h3>Sloved Issues</h3>
                <p>
                  <span
                    style="font-size: 63px;color: #030303;font-weight: bold;"
                  >
                    {{ fixed }}
                  </span>
                  For this week
                </p>
              </div>
              <div class="col-box">
                <img
                  style="box-shadow: none;height: 100%;"
                  src="../../../assets/solv.jpg"
                  alt=""
                />
              </div>
            </div>
          </template>
        </Card>
      </div>
    </div>

    <div class="home-part mb-5">
      <p>
        Reported Issues
        <span
        v-if="totalRecords > 3"
          style="font-size: 17px;float: right;"
          @click="$router.push('/console/list')"
        >
          see ({{ totalRecords - 3 }}) More
        </span>
      </p>
      <div class="row">
        <div class="col-4" v-for="item in issuesList" :key="item._id">
          <Card class="home-card">
            <template #content>
              <SpeedDial
                class="speedbtn"
                :model="items"
                type="quarter-circle"
                showIcon="fa fa-ellipsis-v"
                buttonClassName="p-button-text"
                :radius="50"
                direction="down-left"
                @click="active(item)"
              />

              <h3>
                {{ item.labId ? item.labId.name : '' }}
              </h3>
              <p class="header">
                Posted in
              </p>
              <p class="date">
                {{ $durationFormatFull(item.createdAt) }}
              </p>
              <p class="header">
                Issue
              </p>
              <p class="date">
                {{ item.body }}
              </p>

              <div class="text-right pt-1">
                <Chip
                  class="new"
                  label="New"
                  v-if="item.status == 'new'"
                  icon="pi pi-envelope"
                />
                <Chip
                  class="biding"
                  v-if="item.status == 'biding'"
                  label="biding"
                  icon="pi pi-clock"
                />
                <Chip
                  class="fixed"
                  v-if="item.status == 'fixed'"
                  label="fixed"
                  icon="pi pi-check-circle"
                />
              </div>
            </template>
          </Card>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      items: [
        {
          label: 'Delete',
          icon: 'pi pi-trash',
          command: () => {
            this.$http.delete(`issues/${this.itemId}`).then(
              (response) => {
                this.getData();
                this.$toast.add({
                  severity: 'error',
                  summary: 'Delete',
                  detail: 'Data Deleted',
                });
              },
              (err) => {
                this.$toast.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: err.response.data.message,
                  life: 3000,
                });
              },
            );
          },
        },
        // {
        //   label: 'Update',
        //   icon: 'pi pi-pencil',
        //   command: () => {
        //     this.$router.push('/console/issues/' + this.itemId);
        //   },
        // },
        {
          label: 'show',
          icon: 'pi pi-eye',
          command: () => {
            this.$router.push('/console/showIssues/' + this.itemId);
          },
        },
      ],
      totalRecords: 0,
      labsList: [],
      issuesList: [],
      itemId: null,
      total: 0,
      newI: 0,
      wetting: 0,
      fixed: 0,
      reOpen: 0,

      name: null,
    };
  },
  methods: {
    active(item) {
      this.itemId = item._id;
    },
    toggle(event) {
      this.$refs.menu.toggle(event);
    },
    getData() {
      const user = JSON.parse(localStorage.ujclassUser);
      this.name = user.firstName;
      this.$http.get(`issues?page=1&limit=3`).then(
        (response) => {
          this.issuesList = response.data.docs;

          this.totalRecords = response.data.totalDocs;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    },
  },
  created() {
    this.getData();
    this.$http.post(`issues/count`, {}).then((response) => {
      this.total = response.data;
    });
    this.$http
      .post(`issues/count`, {
        status: 'new',
      })
      .then((response) => {
        this.newI = response.data;
      });
    this.$http
      .post(`issues/count`, {
        status: 'biding',
      })
      .then((response) => {
        this.wetting = response.data;
      });
    this.$http
      .post(`issues/count`, {
        status: 'reOpen',
      })
      .then((response) => {
        this.reOpen = response.data;
      });
    this.$http
      .post(`issues/count`, {
        status: 'fixed',
      })
      .then((response) => {
        this.fixed = response.data;
      });
  },
};
</script>

<style></style>
