<template>
  <div class="container home">
    <div class="home-part mb-5">
      <p>
        Reported Issues
      </p>
      <div class="row">
        <div class="col-4 " v-for="item in issuesList" :key="item._id">
          <Card class="home-card mb-3">
            <template #content>
              <SpeedDial
                class="speedbtn"
                :model="items"
                type="quarter-circle"
                showIcon="fa fa-ellipsis-v"
                buttonClassName="p-button-text"
                :radius="50"
                direction="down-left"
                @click="active(item)"
              />

              <h3>
                {{ item.labId ? item.labId.name : '' }}
              </h3>
              <p class="header">
                Posted in
              </p>
              <p class="date">
                {{ $durationFormatFull(item.createdAt) }}
              </p>
              <p class="header">
                Issue
              </p>
              <p class="date">
                {{ item.body }}
              </p>

              <div class="text-right pt-1">
                <Chip
                  class="new"
                  label="New"
                  v-if="item.status == 'new'"
                  icon="pi pi-envelope"
                />
                <Chip
                  class="biding"
                  v-if="item.status == 'biding'"
                  label="biding"
                  icon="pi pi-clock"
                />
                <Chip
                  class="fixed"
                  v-if="item.status == 'fixed'"
                  label="fixed"
                  icon="pi pi-check-circle"
                />
              </div>
            </template>
          </Card>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      items: [
        {
          label: 'Delete',
          icon: 'pi pi-trash',
          command: () => {
            this.$http.delete(`issues/${this.itemId}`).then(
              (response) => {
                this.getData();
                this.$toast.add({
                  severity: 'error',
                  summary: 'Delete',
                  detail: 'Data Deleted',
                });
              },
              (err) => {
                this.$toast.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: err.response.data.message,
                  life: 3000,
                });
              },
            );
          },
        },
        // {
        //   label: 'Update',
        //   icon: 'pi pi-pencil',
        //   command: () => {
        //     this.$router.push('/console/issues/' + this.itemId);
        //   },
        // },
        {
          label: 'show',
          icon: 'pi pi-eye',
          command: () => {
            this.$router.push('/console/showIssues/' + this.itemId);
          },
        },
      ],

      issuesList: [],
      itemId: null,
    };
  },
  methods: {
    active(item) {
      this.itemId = item._id;
    },
    toggle(event) {
      this.$refs.menu.toggle(event);
    },
    getData() {
      const user = JSON.parse(localStorage.ujclassUser);
      this.$http.get(`issues?page=1&limit=10000`).then(
        (response) => {
          this.issuesList = response.data.docs;

          this.totalRecords = response.data.totalDocs;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    },
  },
  created() {
    this.getData();
  },
};
</script>

<style></style>
