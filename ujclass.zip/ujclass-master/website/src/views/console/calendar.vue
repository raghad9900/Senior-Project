<template>
  <div>
    <section class="page-title text-center">
      <div class="container">
        <div class="content-box">
          <h1>Appointment</h1>
        </div>
      </div>
    </section>

    <!--SECTION START-->
    <section
      style="background-color: white; padding-top: 36px; padding-bottom: 150px"
    >
      <div class="mr-3 ml-3">
        <FullCalendar
          :options="calendarOptions"
          ref="calendar2"
          style="margin-right: 5vw;"
        />
      </div>
      <Dialog
        header="Add Appointment"
        :visible.sync="modalShow"
        :containerStyle="{ width: '50vw' }"
      >
        <form @submit.prevent="add()">
          <div class="mb-3">
            <label for="type" class="form-label">
              Class
            </label>
            <Dropdown
              style="width: 100%;"
              v-model="body.labId"
              :options="labsList"
              optionLabel="name"
              optionValue="_id"
            />
          </div>
          <div class="mb-3">
            <label for="minutes" class="form-label">
              Minutes
            </label>
            <InputText
              style="width: 100%;"
              type="number"
              :min="15"
              v-model.number="minutes"
            />
          </div>

          <div class="mb-3">
            <button class="btn btn-info btn-block">Add</button>
          </div>
        </form>
      </Dialog>
    </section>
  </div>
</template>

<script>
import '@fullcalendar/core/vdom'; // solves problem with Vite
import FullCalendar from '@fullcalendar/vue';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import timeGridPlugin from '@fullcalendar/timegrid';
import moment from 'moment';
// import resourceTimeGridPlugin from '@fullcalendar/resource-timegrid';

export default {
  components: {
    FullCalendar, // make the <FullCalendar> tag available
  },

  data() {
    return {
      modalShow: false,
      minutes: 60,

      calendarOptions: {
        plugins: [
          dayGridPlugin,
          timeGridPlugin,
          interactionPlugin, // needed for dateClick
        ],
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay',
        },
        // initialView: 'resourceTimeGridDay',
        initialView: 'dayGridMonth',
        initialDate: new Date(),
        navLinks: true,
        slotDuration: '00:15:00',
        slotLabelInterval: 15,
        slotMinutes: 15,
        slotLabelFormat: { hour: 'numeric', minute: '2-digit', hour12: false },

        businessHours: true,
        slotMinTime: '07:00',
        slotMaxTime: '22:00',
        selectMirror: true,

        events: [],
        schedulerLicenseKey: 'CC-Attribution-NonCommercial-NoDerivatives',
        selectable: true,
        select: this.handleDateSelect,
        eventClick: this.handleEventClick,
      },
      body: {
        start: null,
        end: null,
        labId: null,
      },
      calendarApi: null,
      labsList: [],
    };
  },

  methods: {
    add() {
      if (this.body.labId && Number(this.minutes) > 15) {
        const start = moment(new Date(this.body.start));
        const end = moment(start).add(Number(this.minutes), 'minutes');
        this.body.end = new Date(end);
        this.modalShow = false;
        this.$http.post(`appointment`, this.body).then(
          (response) => {
            const item = response.data;
            this.calendarApi.addEvent({
              id: item._id,
              title: item.labId.name,
              start: new Date(item.start),
              end: new Date(item.end),
              allDay: false,
            });
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Added Done Success',
              life: 3000,
            });
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      }
    },
    handleEventClick(clickInfo) {
      console.log('handleEventClick', clickInfo);
      this.$router.push('/console/showAppointment/' + clickInfo.event.id);
    },
    handleDateSelect(selectInfo) {
      this.calendarApi = selectInfo.view.calendar;
      // console.log(selectInfo);

      this.calendarApi.unselect(); // clear date selection
      this.body = {
        start: selectInfo.start,
        end: selectInfo.end,
        title: null,
        allDay: false,
      };
      if (selectInfo.allDay == false) {
        this.modalShow = true;
      } else {
        alert('Please click on the number of the day');
      }
    },
    getData() {
      this.$http.get(`labs?page=1&limit=3000000&sort=asc`).then(
        (response) => {
          this.labsList = response.data.docs;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );

      this.$http.get(`appointment?page=1&limit=3000000&sort=asc`).then(
        (response) => {
          const list = response.data.docs;
          for (const item of list) {
            if (item.labId) {
              this.calendarOptions.events.push({
                id: item._id,
                title:
                  item.labId.name +
                  ' By ' +
                  (item.userId
                    ? item.userId.firstName + ' ' + item.userId.lastName
                    : '--'),
                start: new Date(item.start),
                end: new Date(item.end),
                allDay: false,
              });
            }
          }
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    },
  },

  created() {
    this.getData();
  },
};
</script>

<style>
@media (max-width: 767.98px) {
  .fc .fc-view-harness {
    height: 856.296px !important;
  }
}

.fc .fc-scrollgrid-section table {
  width: 100% !important;
  /* height: 825px !important; */
}

.fc-scrollgrid-section-body .fc-scrollgrid-section table {
  width: 100% !important;
  /* height: 856.296px !important; */
}
.asa {
  font-weight: 700;
  font-size: 15px;
  color: rgba(0, 0, 0, 0.5);
}
</style>
