<template>
  <div class="container pt-5 ">
    <div class="row">
      <div class="col-5">
        <Card class="add-card">
          <template #content>
            <form @submit.prevent="add()">
              <div class="mb-3">
                <label for="type" class="form-label">
                  Class
                </label>
                <Dropdown
                  style="width: 100%;"
                  v-model="body.labId"
                  :options="labsList"
                  optionLabel="name"
                  optionValue="_id"
                />
              </div>
              <div class="mb-3">
                <label for="type" class="form-label">
                  Issue Type
                </label>
                <Dropdown
                  style="width: 100%;"
                  v-model="body.issueTypeId"
                  :options="issuesTypesList"
                  optionLabel="name"
                  optionValue="_id"
                />
              </div>

              <div class="mb-3">
                <label for="type" class="form-label">
                  Issue Description
                </label>

                <textarea
                  class="form-control"
                  id="body"
                  rows="5"
                  v-model="body.body"
                />
              </div>

              <div class="mb-3">
                <label for="type" class="form-label">
                  Add attachment
                </label>

                <Button
                  label="Select file"
                  @click="$refs.file.click()"
                  class="p-button-rounded p-button-secondary"
                  style="display: block;"
                />
                <input
                  type="file"
                  ref="file"
                  style="display: none"
                  @change="previewImage"
                  multiple
                />
              </div>
              <div class="mb-3">
                <button class="btn btn-info btn-block">Post</button>
              </div>
            </form>
          </template>
        </Card>
      </div>
      <div class="col-3"></div>
      <div class="col-4">
        <Card class="home-card mb-3" v-for="item in list" :key="item._id">
          <template #content>
            <SpeedDial
              class="speedbtn"
              :model="items"
              type="quarter-circle"
              showIcon="fa fa-ellipsis-v"
              buttonClassName="p-button-text"
              :radius="50"
              direction="down-left"
            />

            <h3>
              {{ item.labId ? item.labId.name : '' }}
            </h3>
            <p class="header">
              Posted in
            </p>
            <p class="date">
              {{ $durationFormatFull(item.createdAt) }}

            </p>
            <p class="header">
              Issue
            </p>
            <p class="date">
              {{ item.body }}
            </p>

            <div class="text-right pt-1">
              <Chip
                class="new"
                label="New"
                v-if="item.status == 'new'"
                icon="pi pi-envelope"
              />
              <Chip
                class="biding"
                v-if="item.status == 'biding'"
                label="biding"
                icon="pi pi-clock"
              />
              <Chip
                class="fixed"
                v-if="item.status == 'fixed'"
                label="fixed"
                icon="pi pi-check-circle"
              />
            </div>
          </template>
        </Card>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      items: [
        {
          label: 'Delete',
          icon: 'pi pi-trash',
          command: () => {
            this.$toast.add({
              severity: 'error',
              summary: 'Delete',
              detail: 'Data Deleted',
            });
          },
        },
        {
          label: 'Delete',
          icon: 'pi pi-trash',
          command: () => {
            this.$toast.add({
              severity: 'error',
              summary: 'Delete',
              detail: 'Data Deleted',
            });
          },
        },
      ],

      labsList: [],
      issuesTypesList: [],
      body: {
        labId: null,
        files: [],
        body: null,
        status: 'new',

        issueTypeId: null,
      },
      list: [],
    };
  },
  methods: {
    getData() {
      const user = JSON.parse(localStorage.ujclassUser);
      this.$http.get(`issues?page=1&limit=10000&userId=${user._id}`).then(
        (response) => {
          this.list = response.data.docs;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    },

    add() {
      if (this.body.labId && this.body.body && this.body.issueTypeId) {
        this.$http.post(`issues`, this.body).then(
          (response) => {
            this.body = {
              labId: null,
              files: [],
              body: null,
              status: 'new',

              issueTypeId: null,
            };
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Added Done Success',
              life: 3000,
            });
            this.getData();
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      }
    },
    async previewImage(ev) {
      if (ev.target.files.length > 0) {
        const list = [];
        for (const item of ev.target.files) {
          const itm = await this.$toBase64(item);
          await list.push(itm);
        }
        this.body.files = await list;
      } else {
        this.body.files = [];
      }
      return await true;
    },
  },
  created() {
    this.getData();
    this.$http.get(`labs?page=1&limit=300000000&sort=asc`).then(
      (response) => {
        this.labsList = response.data.docs;
      },
      (err) => {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: err.response.data.message,
          life: 3000,
        });
      },
    );
    this.$http.get(`issuesTypes?page=1&limit=300000000&sort=asc`).then(
      (response) => {
        this.issuesTypesList = response.data.docs;
      },
      (err) => {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: err.response.data.message,
          life: 3000,
        });
      },
    );
  },
};
</script>

<style></style>
