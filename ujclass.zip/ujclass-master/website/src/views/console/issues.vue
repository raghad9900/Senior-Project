<template>
  <div class="container pt-5 ">
    <div class="row">
      <div class="col-5">
        <Card class="add-card">
          <template #content>
            <form @submit.prevent="add()">
              <div class="row">
                <div class="col-6">
                  <div class="mb-3">
                    <label for="type" class="form-label">
                      Class
                    </label>
                    <Dropdown
                      style="width: 100%;"
                      v-model="body.labId"
                      :options="labsList"
                      optionLabel="name"
                      optionValue="_id"
                    />
                  </div>
                </div>
                <div class="col-6">
                  <div class="mb-3">
                    <label for="type" class="form-label">
                      Issue Type
                    </label>
                    <Dropdown
                      style="width: 100%;"
                      v-model="body.issueTypeId"
                      :options="issuesTypesList"
                      optionLabel="name"
                      optionValue="_id"
                    />
                  </div>
                </div>
                <div class="col-12">
                  <div class="mb-3">
                    <label for="type" class="form-label">
                      Issue Description
                    </label>

                    <textarea
                      class="form-control"
                      id="body"
                      rows="5"
                      v-model="body.body"
                    />
                  </div>
                </div>
                <div class="col-12">
                  <div class="mb-3">
                    <label for="type" class="form-label">
                      Add attachment
                    </label>

                    <Button
                      label="Select file"
                      @click="$refs.file.click()"
                      class="p-button-rounded p-button-secondary"
                      style="display: block;"
                    />
                    <input
                      type="file"
                      ref="file"
                      style="display: none"
                      @change="previewImage"
                      multiple
                    />
                  </div>
                  <ul class="list-group mb-3">
                    <li
                      v-for="(itm, index) in body.files"
                      :key="itm"
                      class="list-group-item d-flex justify-content-between align-items-start"
                    >
                      <div class="ms-2 me-auto">
                        <a
                          :href="$baseUploadURL + itm"
                          target="_blank"
                          rel="noopener noreferrer"
                          >{{ itm }}</a
                        >
                      </div>
                      <span
                        class="badge bg-primary rounded-pill"
                        style="color:brown"
                        @click="body.files.splice(index, 1)"
                        >X</span
                      >
                    </li>
                  </ul>
                </div>
              </div>

              <div class="mb-3">
                <button class="btn btn-info btn-block">Update</button>
              </div>
            </form>
          </template>
        </Card>
      </div>
    </div>
    <div class="col-3"></div>
    <div class="col-4"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      labsList: [],
      issuesTypesList: [],
      body: {
        labId: null,
        files: [],
        body: null,
        status: 'new',

        issueTypeId: null,
      },
    };
  },
  methods: {
    getData() {
      const id = this.$route.params.id;
      this.$http.get(`issues/${id}`).then(
        (response) => {
          this.body = response.data;
          this.body.labId = response.data.labId
            ? response.data.labId._id
            : null;
          this.body.issueTypeId = response.data.issueTypeId
            ? response.data.issueTypeId._id
            : null;
        },
        (err) => {
          this.$toast.add({
            severity: 'error',
            summary: 'Error',
            detail: err.response.data.message,
            life: 3000,
          });
        },
      );
    },

    add() {
      const id = this.$route.params.id;
      if (this.body.labId && this.body.body && this.body.issueTypeId) {
        this.$http.put(`issues/${id}`, this.body).then(
          (response) => {
           
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Added Done Success',
              life: 3000,
            });
            this.getData();
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      }
    },
    async previewImage(ev) {
      if (ev.target.files.length > 0) {
        const list = [];
        for (const item of ev.target.files) {
          const itm = await this.$toBase64(item);
          await this.body.files.push(itm);
        }
        // this.body.files = await list;
      }
      //  else {
      //   this.body.files = [];
      // }
      return await true;
    },
  },
  created() {
    this.getData();
    this.$http.get(`labs?page=1&limit=300000000&sort=asc`).then(
      (response) => {
        this.labsList = response.data.docs;
      },
      (err) => {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: err.response.data.message,
          life: 3000,
        });
      },
    );
    this.$http.get(`issuesTypes?page=1&limit=300000000&sort=asc`).then(
      (response) => {
        this.issuesTypesList = response.data.docs;
      },
      (err) => {
        this.$toast.add({
          severity: 'error',
          summary: 'Error',
          detail: err.response.data.message,
          life: 3000,
        });
      },
    );
  },
};
</script>

<style></style>
