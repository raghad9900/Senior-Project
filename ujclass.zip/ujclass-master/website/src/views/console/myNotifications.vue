<template>
  <div>
    <div class="data">
      <div class="container">
        <div>
          <p class="following follow-bttn">My Notifications</p>
        </div>

        <section>
          <div v-if="loading">
            <div
              class="d-flex justify-content-between w-100 electronics"
              v-for="item of notificationsList"
              @click="$router.push('/console/showIssues/' + item._id)"
              :key="item._id"
            >
              <div class="d-flex person">
               
               
                <div class="ms-2 me-auto" v-if="item.commentsId">
                  <div class="fw-bold" style="font-weight: bold;">{{ item.body }}</div>
                 #{{item.issueId.id}} - {{item.commentsId.body}}
                </div>
                <div class="ms-2 me-auto" v-else>
                  <div class="fw-bold" style="font-weight: bold;">{{ item.body }}</div>
                 #{{item.issueId.id}} - {{item.issueId.body}}
                </div>
              </div>
            </div>
          </div>

         
         
        </section>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      notificationsList: [],

      loading: false,
    };
  },
  methods: {
    getData() {
      const user = JSON.parse(localStorage.ujclassUser);

      this.$http
        .post(`notifications/search`, {
          userId: user._id,
        })
        .then((response) => {
          this.loading = true;
          this.notificationsList = response.data.docs;
        });
    },
  },
  created() {
    this.getData();
  },
};
</script>

<style scoped>
.follow img {
  margin-bottom: 5px;
}
p.following {
  padding-top: 15px;
}
.search {
  position: absolute;
  left: 11px;
  bottom: 22px;
  color: #bdb8b8;
}
section {
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
}
.electronics {
  margin-bottom: 20px;
  position: relative;
}
.electronics:after {
  content: '';
  position: absolute;
  width: 100%;
  height: 1px;
  background-color: #d1cece;
  display: block;
  bottom: -5px;
}
.electronics img {
  width: 45px;
  height: 45px;
}
.electronics .text {
  margin-left: 20px;
}
.electronics .text p {
  color: #172b4d;
  font-weight: bold;
  margin-bottom: 0;
}
.electronics .text h5 {
  color: #7a869a;
}
.follow-btn {
  position: relative;
}
.follow-btn .check-icon {
  color: #fff;
  background-color: #a29ef2;
  border-radius: 50%;
  padding: 3px;
  font-size: 2px;
  position: absolute;
  left: 23px;
  bottom: 25px;
}
.follow-btn button {
  color: #a29ef2;
  border: none;
  outline: none;
  border-radius: 10px;
  padding: 5px 15px 5px 30px;
  background-color: #f4f5f7;
}
.btn-secondary:not(:disabled):not(.disabled):active,
.btn-secondary:not(:disabled):not(.disabled).active,
.show > .btn-secondary.dropdown-toggle {
  border: none;
}
@media (max-width: 767px) {
  .electronics {
    flex-wrap: wrap;
  }
  .electronics .follow-btn {
    margin-top: 15px;
    margin-bottom: 15px;
  }
}
</style>
