<template>
  <div class="home">
    <div class="top-section p-5">
      <h1>
        Manage your classes With
        <br />
        UJ class easily!
      </h1>
    </div>
    <div class="row p-5 bottom-section text-center">
      <div class="col-6">
        <img src="../assets/Stuck at Home - Home Office.png" alt="" />
      </div>
      <div class="col-6">
        <p>
          jion our community
        </p>
        <button class="btn btn-light btn-home" @click="$router.push('/signup/1')">
          Academic staff
        </button>
        <br />
        <button
          class="btn btn-primary btn-home btn-blue"
          @click="$router.push('/signup/2')"
        >
          Mentanince staff
        </button>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
