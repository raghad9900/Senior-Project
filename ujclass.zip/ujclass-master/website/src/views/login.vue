<template>
  <div class="home">
    <div class="top-section p-5">
      <h1>
        Manage your classes With
        <br />
        UJ class easily!
      </h1>
    </div>
    <div class="row p-5 bottom-section text-center">
      <div class="col-6">
        <img src="../assets/Stuck at Home - Home Office.png" alt="" />
      </div>
      <div class="col-6">
        <form  @submit.prevent="loginForm()">
          <Card style="width: 66%;margin: auto;padding-bottom: 20px;">
            <template #title>
              Welcome Back
            </template>
            <template #content>
              <div class="form-group text-left">
                <label for="email">Email address</label>
                <InputText
                  style="width: 100%;"
                  type="email"
                  v-model="user.email"
                  id="email"
                  placeholder="Enter your email address"
                />
              </div>
              <div class="form-group text-left">
                <label for="password">Password</label>
                <InputText
                  style="width: 100%;"
                  type="password"
                  v-model="user.password"
                  id="password"
                  placeholder="Enter your password"
                />
              </div>
            </template>
            <template #footer>
              <button type="submit" class="btn btn-primary btn-block">
                Log In
              </button>
              <div class="text-right">
                <router-link to="/forgetpassword"
                  >Forget your password?</router-link
                >
              </div>
            </template>
          </Card>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      user: {
        email: null,
        password: null,
      },
    };
  },

  methods: {
    loginForm() {
      if (this.user.email && this.user.password) {
        this.$http.post(`auth/login`, this.user).then(
          (response) => {
            localStorage.ujclassUser = JSON.stringify(response.data);

            location.reload();
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      }
    },
  },
  created() {},
};
</script>
