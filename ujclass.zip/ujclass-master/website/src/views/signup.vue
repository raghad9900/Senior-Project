<template>
  <div class="home">
    <div class="top-section p-5">
      <h1>
        Manage your classes With
        <br />
        UJ class easily!
      </h1>
    </div>
    <div class="row p-5 bottom-section text-center">
      <div class="col-6">
        <img src="../assets/Stuck at Home - Home Office.png" alt="" />
      </div>
      <div class="col-6">
        <form @submit.prevent="loginForm()">
          <Card style="width: 66%;margin: auto;padding-bottom: 20px;">
            <template #title>
              Sign up
            </template>
            <template #content>
              <div class="form-group text-left row mr-1 ml-1">
                <InputText
                  class=" col-6"
                  v-model="user.firstName"
                  style="width: 98%;"
                  placeholder="First Name"
                />
                <InputText
                  class=" col-6"
                  v-model="user.lastName"
                  style="width: 100%;"
                  placeholder="Last Name"
                />
              </div>
              <div class="form-group text-left">
                <InputText
                  type="email"
                  id="email"
                  style="width: 100%;"
                  placeholder="Email address *"
                  v-model="user.email"
                />
              </div>

              <div class="form-group text-left">
                <InputText
                  type="password"
                  style="width: 100%;"
                  id="password"
                  v-model="user.password"
                  placeholder="password *"
                />
              </div>
            </template>
            <template #footer>
              <button type="submit" class="btn btn-primary btn-block">
                Sign up
              </button>
              <div class="text-right">
                <router-link to="/login"
                  >already have an account? log in</router-link
                >
              </div>
            </template>
          </Card>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      user: {
        firstName: null,
        lastName: null,
        type: 1,
        email: null,
        password: null,
      },
    };
  },

  methods: {
    loginForm() {
      if (
        this.user.firstName &&
        this.user.lastName &&
        this.user.email &&
        this.user.password
      ) {
        this.$http.post(`auth/signup`, this.user).then(
          (response) => {
            this.$toast.add({
              severity: 'success',
              summary: 'Done Success',
              detail: 'Added Done Success',
              life: 3000,
            });
            this.$router.push('/login');
          },
          (err) => {
            this.$toast.add({
              severity: 'error',
              summary: 'Error',
              detail: err.response.data.message,
              life: 3000,
            });
          },
        );
      }
    },
  },
  created() {
    this.user.type = this.$route.params.id;
  },
};
</script>
